#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Soru 6: Ters Üçgen

print("Lütfen satır sayısı (N) girin:")
n = int(input())
for i in range(n, 1 - 1, -1):
    for j in range(1, i + 1, 1):
        print("*", end='', flush=True)
    print("")


# In[3]:


#Soru 7: Boş Kare Çizme  

print("Lütfen karenin boyutunu (N) girin:")
n = int(input())
for i in range(1, n + 1, 1):
    for j in range(1, n + 1, 1):
        if i == 1 or i == n or j == 1 or j == n:
            print("*", end='', flush=True)
        else:
            print(" ", end='', flush=True)
    print("")


# In[4]:


# Soru 8: Pozitif-Negatif-Sıfır Sayacı
# 1. Sayaçları başlat
pozitif_sayac = 0
negatif_sayac = 0
sifir_sayac = 0

print("Lütfen 10 adet sayı girin.")

# 2. For döngüsü ile 10 adet sayı al
# range(10) 0'dan 9'a kadar 10 kez döner.
for i in range(10):
    # Kullanıcıdan sayıyı al ve tam sayıya (int) çevir
    # (i+1) kullanarak "1. sayı", "2. sayı" şeklinde sormak için
    sayi = int(input(f"Lütfen {i+1}. sayıyı girin: "))
    
    # 3. Koşul blokları ile sayıyı kontrol et
    if sayi > 0:
        pozitif_sayac += 1  # pozitif_sayac = pozitif_sayac + 1
    elif sayi < 0:
        negatif_sayac += 1
    else:
        sifir_sayac += 1

# 4. Döngü bittikten sonra sonuçları yazdır
print("\n--- Sonuçlar ---")
print(f"Pozitif Sayı Adedi: {pozitif_sayac}")
print(f"Negatif Sayı Adedi: {negatif_sayac}")
print(f"Sıfır Adedi: {sifir_sayac}")


# In[5]:


# Soru 9: Geçme Notu Kontrolü
# 1. Başlangıç sayaçlarını tanımlıyoruz
gecen_sayisi = 0
kalan_sayisi = 0

print("Lütfen 5 öğrencinin notunu (0-100) girin.\n")

# 2. 5 kez dönecek bir 'for' döngüsü başlatıyoruz
# range(5) 0, 1, 2, 3, 4 değerlerini üreterek 5 kez çalışır
for i in range(5):
    # (i+1) kullanarak "1. öğrenci", "2. öğrenci" vb. yazdırıyoruz
    not_degeri = int(input(f"{i+1}. öğrencinin notunu girin: "))
    
    # 3. Notu değerlendirmek için koşul blokları
    # Koşullar en alttan (veya en üstten) sıralı gitmelidir.
    
    if not_degeri < 50:
        print(f"   -> Durum: Kaldı")
        kalan_sayisi += 1
        
    elif not_degeri < 70:  # (Zaten 50'den büyük olduğu biliniyor, 50-69 aralığı)
        print(f"   -> Durum: Geçti")
        gecen_sayisi += 1
        
    elif not_degeri < 85:  # (Zaten 70'den büyük olduğu biliniyor, 70-84 aralığı)
        print(f"   -> Durum: İyi")
        gecen_sayisi += 1
        
    else:  # (Zaten 85'ten büyük olduğu biliniyor, 85-100 aralığı)
        print(f"   -> Durum: Pekiyi")
        gecen_sayisi += 1

# 4. Döngü bittikten sonra genel sonucu yazdır
print("\n--- SINIF ÖZETİ ---")
print(f"Geçen Öğrenci Sayısı: {gecen_sayisi}")
print(f"Kalan Öğrenci Sayısı: {kalan_sayisi}")


# In[6]:


# Soru10: Yaş Grubu Belirleme 
# 1. Tüm sayaçları döngüden önce sıfırla
cocuk_sayisi = 0
genc_sayisi = 0
yetiskin_sayisi = 0
yasli_sayisi = 0

print("Yaş grubu belirleme programı (Çıkmak için -1 girin).")

# 2. Sonsuz bir 'while True' döngüsü başlat
# Döngüyü içeriden 'break' komutu ile kıracağız.
while True:
    # 3. Kullanıcıdan yaş al ve sayıya çevir
    yas = int(input("\nLütfen bir yaş girin: "))
    
    # 4. İlk olarak ÇIKIŞ KOŞULUNU kontrol et
    if yas == -1:
        print("Program sonlandırılıyor...")
        break  # 'while' döngüsünü sonlandır
        
    # 5. Geçersiz girişleri kontrol et (Negatif yaş)
    if yas < 0:
        print("Geçersiz! Lütfen 0 veya daha büyük bir yaş girin.")
        continue # Döngünün bu adımını atla, başa dön

    # 6. Yaş grubunu belirle ve sayacı artır
    if yas <= 12:  # 0-12
        print(f"{yas} yaş -> Grup: Çocuk")
        cocuk_sayisi += 1
        
    elif yas <= 17: # 13-17
        print(f"{yas} yaş -> Grup: Genç")
        genc_sayisi += 1
        
    elif yas <= 64: # 18-64
        print(f"{yas} yaş -> Grup: Yetişkin")
        yetiskin_sayisi += 1
        
    else: # 65+
        print(f"{yas} yaş -> Grup: Yaşlı")
        yasli_sayisi += 1

# 7. Döngü bittiğinde (kullanıcı -1 girdiğinde) final raporu yazdır
print("\n--- YAŞ GRUBU RAPORU ---")
print(f"Çocuk (0-12):   {cocuk_sayisi} kişi")
print(f"Genç (13-17):    {genc_sayisi} kişi")
print(f"Yetişkin (18-64): {yetiskin_sayisi} kişi")
print(f"Yaşlı (65+):     {yasli_sayisi} kişi")


# In[ ]:




